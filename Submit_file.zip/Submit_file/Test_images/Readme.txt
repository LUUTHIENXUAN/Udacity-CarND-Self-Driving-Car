Downloaded images can be found in: 
https://discussions.udacity.com/t/i-was-stuck-0-97-validation-accuracy-but-0-in-testing-model-on-new-images/305042/2
